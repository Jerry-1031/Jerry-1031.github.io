#include "cli.hpp"
#include "exact_solver.hpp"
#include "map_io.hpp"

int main(int argc, char **argv) try {
    if (argc < 6 || std::string(argv[1]) == "--help") {
        std::cout << "Usage: polish N THREADS WINDOW SEED_MAP PREFIX [--quiet]\n"
                  << "N: 3..8. WINDOW: 1..4. Checks every binary window rewrite until no strict gain.\n";
        return argc == 2 && std::string(argv[1]) == "--help" ? 0 : 2;
    }
    int n = number<int>(argv[1], "N"), threads = number<int>(argv[2], "THREADS"),
        width = number<int>(argv[3], "WINDOW");
    if (n < 3 || n > 8 || threads < 1 || threads > 256 || width < 1 || width > 4 || width > n)
        throw std::runtime_error("Requires 3 <= N <= 8, 1 <= THREADS <= 256, 1 <= WINDOW <= min(4,N)");
    bool quiet = false;
    for (int i = 6; i < argc; ++i) {
        if (std::string(argv[i]) == "--quiet")
            quiet = true;
        else
            throw std::runtime_error("Unknown option: " + std::string(argv[i]));
    }
    Layout layout(n);
    Board seed = load_seed(argv[4], n);
    U initial = 0;
    for (int y = 0; y < n; ++y)
        for (int x = 0; x < n; ++x)
            if (seed.floor[(y + 1) * W + x + 1])
                initial |= U(1) << (y * n + x);
    prepare_output(argv[5]);
    Shared shared(layout, -1, argv[5], quiet);
    auto evaluate = [&](Solver &solver, U mask) {
        while (mask) {
            U component = mask & -mask;
            for (;;) {
                U next = component | (layout.expand(component) & mask);
                if (next == component)
                    break;
                component = next;
            }
            mask &= ~component;
            U canonical = component;
            for (int t = 1; t < 8; ++t)
                canonical = std::min(canonical, layout.transform(component, t));
            solver.evaluate(canonical);
        }
    };
    Solver seed_solver(layout, shared, true, true, true);
    evaluate(seed_solver, initial);
    if (shared.best < 1)
        throw std::runtime_error("Seed has no solvable placement");
    std::vector<std::vector<Record>> all_records;
    all_records.push_back(std::move(seed_solver.records));
    U evaluated = 0;
    int rounds = 0;
    auto start = std::chrono::steady_clock::now();
    for (;;) {
        int before = shared.best;
        U base = shared.witness.mask;
        std::vector<U> windows;
        std::vector<std::vector<U>> patterns;
        for (int y = 0; y <= n - width; ++y)
            for (int x = 0; x <= n - width; ++x) {
                std::vector<U> v(U(1) << (width * width));
                U window = 0;
                for (int k = 0; k < width * width; ++k)
                    window |= U(1) << ((y + k / width) * n + x + k % width);
                for (size_t k = 1; k < v.size(); ++k) {
                    int bit = first(k);
                    v[k] = v[k & (k - 1)] | (U(1) << ((y + bit / width) * n + x + bit % width));
                }
                windows.push_back(window);
                patterns.push_back(std::move(v));
            }
        U variants = U(1) << (width * width), total = windows.size() * variants;
        std::atomic<U> next{0};
        std::vector<std::thread> workers;
        std::vector<std::vector<Record>> records(threads);
        for (int worker = 0; worker < threads; ++worker)
            workers.emplace_back([&, worker] {
                Solver solver(layout, shared, true, true, true);
                for (;;) {
                    U at = next.fetch_add(64);
                    if (at >= total)
                        break;
                    for (U task = at; task < std::min(total, at + 64); ++task) {
                        U wi = task / variants, pattern = task % variants;
                        evaluate(solver, (base & ~windows[wi]) | patterns[wi][pattern]);
                    }
                }
                records[worker] = std::move(solver.records);
            });
        for (auto &worker : workers)
            worker.join();
        for (auto &batch : records)
            all_records.push_back(std::move(batch));
        evaluated += total;
        ++rounds;
        if (!quiet)
            std::cout << "round " << rounds << " evaluated " << evaluated << " best " << shared.best
                      << std::endl;
        if (shared.best == before)
            break;
    }
    OptimalStats observed(n);
    for (const auto &batch : all_records)
        for (const auto &r : batch)
            if (r.score == shared.best) {
                U spare = layout.full & ~(r.mask | layout.expand(r.mask));
                for (U extra = spare;; extra = (extra - 1) & spare) {
                    std::string map(n * n, '#');
                    for (int p = 0; p < n * n; ++p)
                        if ((r.mask | extra) >> p & 1)
                            map[p] = '-';
                    map[r.p] = '@';
                    map[r.b] = '$';
                    map[r.g] = '.';
                    observed.add(r.score, map);
                    if (!extra)
                        break;
                }
            }
    double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
    observed.save(std::string(argv[5]) + "_optimal.xsb");
    std::ofstream out(std::string(argv[5]) + ".json");
    out << "{\"n\":" << n << ",\"threads\":" << threads << ",\"window\":" << width << ",\"rounds\":" << rounds
        << ",\"evaluated\":" << evaluated << ",\"best\":" << shared.best << ",\"elapsed_seconds\":" << elapsed
        << ",\"exhaustive\":false,\"final_window_neighborhood_complete\":true,\"counts_complete\":false,"
           "\"observed_optimal\":";
    observed.write(out);
    out << "}\n";
    return 0;
} catch (const std::exception &error) {
    std::cerr << "error: " << error.what() << '\n';
    return 1;
}
