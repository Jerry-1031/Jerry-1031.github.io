param(
    [string]$Compiler = "g++",
    [switch]$Portable
)
$ErrorActionPreference = "Stop"
$outputDirectory = Join-Path $PSScriptRoot "bin"
New-Item -ItemType Directory -Force -Path $outputDirectory | Out-Null
$flags = @("-O3", "-std=c++17", "-pthread", "-Wall", "-Wextra")
if (-not $Portable) { $flags += "-march=native" }
foreach ($program in @("exact", "heuristic", "polish")) {
    & $Compiler @flags (Join-Path $PSScriptRoot "$program.cpp") -o (Join-Path $outputDirectory "$program.exe")
    if ($LASTEXITCODE -ne 0) { throw "Build failed: $program" }
}
Write-Output "Built exact, heuristic, polish in $outputDirectory"
