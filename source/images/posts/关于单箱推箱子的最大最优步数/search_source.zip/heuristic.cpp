#include "cli.hpp"
#include "map_io.hpp"
#include "optimal_stats.hpp"
#include "scoped_solver.hpp"
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <mutex>
#include <random>
#include <stdexcept>
#include <thread>
#include <unordered_set>
#include <vector>

struct Population {
    std::mutex mutex;
    std::atomic<int> best_score{-1};
    std::atomic<uint64_t> evaluated{0};
    Board best;
    std::vector<Board> pool;
    std::vector<uint64_t> pool_hashes;
    std::atomic<uint64_t> cache_hits{0};
    std::string prefix;
    int side;
    bool quiet = false;
    OptimalStats observed;
    std::unordered_set<std::string> counted_layouts;
    explicit Population(int n) : side(n), observed(n) {}
    void save_small(const Board &a) {
        std::ofstream out(prefix + "_best.xsb");
        for (int y = 1; y <= side; ++y) {
            for (int x = 1; x <= side; ++x) {
                int p = y * W + x;
                out << (p == a.p ? '@' : p == a.b ? '$' : p == a.g ? '.' : a.floor[p] ? '-' : '#');
            }
            out << '\n';
        }
    }
    void submit(Board a, ScopedSolver &solver, std::mt19937 &rng) {
        bool collect = false;
        if (a.score >= best_score.load()) {
            std::string key;
            for (int y = 1; y <= side; ++y)
                for (int x = 1; x <= side; ++x)
                    key += a.floor[y * W + x] ? '-' : '#';
            std::string canonical = key;
            for (int t = 1; t < 8; ++t)
                canonical = std::min(canonical, observed.transform(key, t));
            std::lock_guard<std::mutex> guard(mutex);
            collect = counted_layouts.insert(canonical).second;
        }
        std::vector<std::string> maps;
        if (collect || a.score > best_score.load()) {
            solver.optimize(a, true);
            Board check = a;
            if (solver.forward(check) != a.score)
                throw std::runtime_error("Independent direction mismatch");
            maps = solver.optimal_maps(a, side);
        }
        std::lock_guard<std::mutex> guard(mutex);
        if (a.score > best_score.load()) {
            best = a;
            best_score = a.score;
            save_small(a);
            if (!quiet)
                std::cout << "best " << a.score << " evaluated " << evaluated.load() << std::endl;
        }
        for (const auto &s : maps)
            observed.add(a.score, s);
        if (a.score >= best_score.load() * 0.70 && a.score > 0) {
            uint64_t hash = hash_board(a);
            bool duplicate = std::find(pool_hashes.begin(), pool_hashes.end(), hash) != pool_hashes.end();
            if (!duplicate) {
                if (pool.size() < 96) {
                    pool.push_back(a);
                    pool_hashes.push_back(hash);
                } else {
                    size_t slot = rng() % pool.size();
                    if (a.score >= pool[slot].score || rng() % 8 == 0) {
                        pool[slot] = a;
                        pool_hashes[slot] = hash;
                    }
                }
            }
        }
    }
};

int main(int argc, char **argv) try {
    if (argc < 7 || std::string(argv[1]) == "--help") {
        std::cout << "Usage: heuristic N SECONDS THREADS RNG_SEED MAP_OR_DASH PREFIX [--quiet]\n"
                  << "N: 3..20. A smaller seed is padded with walls. Use - for an open square.\n";
        return argc == 2 && std::string(argv[1]) == "--help" ? 0 : 2;
    }
    int side = number<int>(argv[1], "N"), seconds = number<int>(argv[2], "SECONDS"),
        threads = number<int>(argv[3], "THREADS");
    unsigned seed = number<unsigned>(argv[4], "RNG_SEED");
    if (side < 3 || side > 20 || threads < 1 || threads > 32 || seconds < 1)
        throw std::runtime_error("Requires 3 <= N <= 20, 1 <= THREADS <= 32, SECONDS >= 1");
    Population population(side);
    population.prefix = argv[6];
    for (int i = 7; i < argc; ++i) {
        if (std::string(argv[i]) == "--quiet")
            population.quiet = true;
        else
            throw std::runtime_error("Unknown option: " + std::string(argv[i]));
    }
    prepare_output(argv[6]);
    Board initial = load_seed(argv[5], side);
    ScopedSolver initial_solver;
    initial_solver.optimize(initial, true);
    if (initial.score < 1)
        throw std::runtime_error("Seed topology has no solvable distinct-marker placement");
    population.best = initial;
    population.best_score = initial.score;
    population.pool.push_back(initial);
    population.pool_hashes.push_back(hash_board(initial));
    population.save_small(initial);
    std::mt19937 initial_rng(seed);
    population.submit(initial, initial_solver, initial_rng);
    auto start = std::chrono::steady_clock::now();
    auto deadline = start + std::chrono::seconds(seconds);
    std::vector<std::thread> workers;
    for (int worker = 0; worker < threads; ++worker)
        workers.emplace_back([&, worker] {
            ScopedSolver solver;
            std::mt19937 rng(seed + 7919 * worker);
            struct CacheEntry {
                uint64_t floor = 0;
                int p = -1, b = -1, g = -1;
                Board result;
            };
            std::vector<CacheEntry> cache(side <= 8 ? 16384 : 0);
            Board current = initial;
            uint64_t evaluated = 0, hits = 0;
            for (int iteration = 0; std::chrono::steady_clock::now() < deadline; ++iteration) {
                int epoch = 2000 + (worker % 4) * 4000;
                if (iteration % epoch == 0) {
                    std::lock_guard<std::mutex> lock(population.mutex);
                    current = rng() % 3 ? population.pool[rng() % population.pool.size()] : population.best;
                    if (rng() % 8 == 0) {
                        for (int y = 1; y <= side; ++y)
                            for (int x = 1; x <= side; ++x)
                                current.floor[y * W + x] = rng() % 100 < 60 + rng() % 20;
                    }
                }
                Board t = current;
                int type = rng() % 100;
                if (type < 67) {
                    int k = type < 37 ? 1 : type < 56 ? 2 : 3 + rng() % 4;
                    for (int j = 0; j < k; ++j)
                        t.floor[(1 + rng() % side) * W + 1 + rng() % side] ^= 1;
                } else if (type < 87) {
                    int height = 2 + rng() % std::min(5, side - 1), width = 2 + rng() % std::min(5, side - 1);
                    int y = 1 + rng() % (side - height + 1), x = 1 + rng() % (side - width + 1);
                    if (rng() % 2) {
                        int kind = rng() % 5, amount = rng() % 2 ? 1 : -1;
                        t = transform(current, y, x, y + height - 1, x + width - 1, kind, amount);
                    } else {
                        for (int j = 0; j < height; ++j)
                            for (int k = 0; k < width; ++k)
                                if (rng() % 3 == 0)
                                    t.floor[(y + j) * W + x + k] ^= 1;
                    }
                } else if (type < 95) {
                    Board donor;
                    {
                        std::lock_guard<std::mutex> lock(population.mutex);
                        donor = population.pool[rng() % population.pool.size()];
                    }
                    int y1 = 1 + rng() % side, x1 = 1 + rng() % side;
                    int y2 = y1 + rng() % (side - y1 + 1), x2 = x1 + rng() % (side - x1 + 1);
                    for (int y = y1; y <= y2; ++y)
                        for (int x = x1; x <= x2; ++x)
                            t.floor[y * W + x] = donor.floor[y * W + x];
                } else
                    t.g = (1 + rng() % side) * W + 1 + rng() % side;
                auto repair = [&](int &p) {
                    if (!t.floor[p]) {
                        for (int i = 0; i < 64; ++i) {
                            int q = (1 + rng() % side) * W + 1 + rng() % side;
                            if (t.floor[q]) {
                                p = q;
                                return;
                            }
                        }
                    }
                };
                repair(t.g);
                repair(t.p);
                repair(t.b);
                CacheEntry *entry = nullptr;
                uint64_t mask = 0;
                int input_p = t.p, input_b = t.b, input_g = t.g;
                if (!cache.empty()) {
                    for (int y = 1; y <= side; ++y)
                        for (int x = 1; x <= side; ++x)
                            if (t.floor[y * W + x])
                                mask |= uint64_t(1) << ((y - 1) * side + x - 1);
                    uint64_t key = mask ^ (uint64_t(t.p) * 0x9e3779b97f4a7c15ULL) ^
                                   (uint64_t(t.b) * 0xbf58476d1ce4e5b9ULL) ^
                                   (uint64_t(t.g) * 0x94d049bb133111ebULL);
                    entry = &cache[(key ^ (key >> 32)) & (cache.size() - 1)];
                }
                if (entry && entry->floor == mask && entry->p == input_p && entry->b == input_b &&
                    entry->g == input_g) {
                    t = entry->result;
                    ++hits;
                } else {
                    solver.optimize(t, false);
                    if (entry) {
                        entry->floor = mask;
                        entry->p = input_p;
                        entry->b = input_b;
                        entry->g = input_g;
                        entry->result = t;
                    }
                }
                ++evaluated;
                if ((iteration % 300 == 0 && t.score > current.score * 0.9) ||
                    t.score > population.best_score.load())
                    solver.optimize(t, true);
                double temperature = std::max(1.0, population.best_score.load() * 0.075) *
                                     (0.15 + 0.85 * (1.0 - (iteration % epoch) / double(epoch)));
                if (t.score >= current.score ||
                    (t.score > 0 && std::generate_canonical<double, 32>(rng) <
                                        std::exp((t.score - current.score) / temperature)))
                    current = t;
                if (t.score >= population.best_score.load() ||
                    (iteration % 47 == 0 && t.score > population.best_score.load() * 0.7))
                    population.submit(t, solver, rng);
                if (evaluated >= 1024) {
                    population.evaluated += evaluated;
                    evaluated = 0;
                }
            }
            population.evaluated += evaluated;
            population.cache_hits += hits;
        });
    for (auto &worker : workers)
        worker.join();
    double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
    population.save_small(population.best);
    std::ofstream out(population.prefix + ".json");
    out << "{\"side\":" << side << ",\"threads\":" << threads << ",\"seed\":" << seed
        << ",\"evaluated\":" << population.evaluated.load() << ",\"best\":" << population.best_score.load()
        << ",\"cache_hits\":" << population.cache_hits.load() << ",\"elapsed_seconds\":" << elapsed
        << ",\"exhaustive\":false,\"counts_complete\":false,\"observed_optimal\":";
    population.observed.write(out);
    out << "}\n";
    population.observed.save(population.prefix + "_optimal.xsb");
    if (!population.quiet)
        std::cout << "finished best " << population.best_score.load() << " evaluated "
                  << population.evaluated.load() << std::endl;
    return 0;
} catch (const std::exception &error) {
    std::cerr << "error: " << error.what() << '\n';
    return 1;
}
