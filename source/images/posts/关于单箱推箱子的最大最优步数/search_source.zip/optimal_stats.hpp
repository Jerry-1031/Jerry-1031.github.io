#pragma once
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <map>
#include <set>
#include <string>
#include <vector>

// A map includes its three labelled markers; equivalence is the square's D4 action.
struct OptimalStats {
    int n, best = -1;
    std::map<std::string, int> maps, layouts;
    explicit OptimalStats(int side) : n(side) {}
    std::string transform(const std::string &s, int t) const {
        std::string out(s.size(), '#');
        for (int p = 0; p < n * n; ++p) {
            int y = p / n, x = p % n;
            if (t >= 4)
                x = n - 1 - x;
            for (int k = 0; k < t % 4; ++k) {
                int yy = x;
                x = n - 1 - y;
                y = yy;
            }
            out[y * n + x] = s[p];
        }
        return out;
    }
    void insert(std::map<std::string, int> &dest, const std::string &s) {
        std::set<std::string> orbit;
        for (int t = 0; t < 8; ++t)
            orbit.insert(transform(s, t));
        dest.emplace(*orbit.begin(), int(orbit.size()));
    }
    void add(int score, const std::string &s) {
        if (score < best || score < 0)
            return;
        if (score > best) {
            best = score;
            maps.clear();
            layouts.clear();
        }
        insert(maps, s);
        std::string floor = s;
        for (char &c : floor)
            if (c != '#')
                c = '-';
        insert(layouts, floor);
    }
    void write(std::ostream &out) const {
        using Counts = std::array<uint64_t, 4>;
        std::map<int, Counts> by_f;
        uint64_t raw = 0, wall_raw = 0;
        for (const auto &[s, orbit] : maps) {
            int f = int(s.size() - std::count(s.begin(), s.end(), '#'));
            raw += orbit;
            by_f[f][0] += orbit;
            ++by_f[f][1];
        }
        for (const auto &[s, orbit] : layouts) {
            int f = int(s.size() - std::count(s.begin(), s.end(), '#'));
            wall_raw += orbit;
            by_f[f][2] += orbit;
            ++by_f[f][3];
        }
        out << "{\"score\":" << best << ",\"maps\":" << raw << ",\"essential_maps\":" << maps.size()
            << ",\"layouts\":" << wall_raw << ",\"essential_layouts\":" << layouts.size() << ",\"by_F\":[";
        bool comma = false;
        for (const auto &[f, c] : by_f) {
            if (comma)
                out << ',';
            comma = true;
            out << "{\"F\":" << f << ",\"maps\":" << c[0] << ",\"essential_maps\":" << c[1]
                << ",\"layouts\":" << c[2] << ",\"essential_layouts\":" << c[3] << '}';
        }
        out << "]}";
    }
    void save(const std::string &path) const {
        std::ofstream out(path);
        int index = 0;
        for (const auto &[s, orbit] : maps) {
            out << "; map " << ++index << " score " << best << " orbit " << orbit << '\n';
            for (int y = 0; y < n; ++y)
                out << s.substr(y * n, n) << '\n';
            out << '\n';
        }
    }
};
