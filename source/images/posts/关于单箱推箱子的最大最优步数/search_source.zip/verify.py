"""Run counted enumeration regressions and independently solve saved maps."""
import argparse
import json
import os
import subprocess
import tempfile
from collections import defaultdict, deque
from pathlib import Path


def solve(rows):
    n = len(rows)
    flat = "".join(rows)
    assert all(len(row) == n for row in rows)
    assert set(flat) <= set("#-@$+.")
    assert sum(flat.count(c) for c in "@+") == 1
    assert flat.count("$") == 1 and sum(flat.count(c) for c in ".+") == 1
    p = next(i for i, c in enumerate(flat) if c in "@+")
    b = flat.index("$")
    g = next(i for i, c in enumerate(flat) if c in ".+")
    floor = {i for i, c in enumerate(flat) if c != "#"}
    neighbors = {i: [] for i in floor}
    for i in floor:
        for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            y, x = i//n+dy, i%n+dx
            j = y*n+x
            if 0 <= y < n and 0 <= x < n and j in floor:
                neighbors[i].append(j)
    queue = deque([((p, b), 0)])
    seen = {(p, b)}
    while queue:
        (p, b), distance = queue.popleft()
        if b == g:
            return distance
        for pp in neighbors[p]:
            bb = b
            if pp == b:
                bb = 2*b-p
                if bb not in neighbors[b]:
                    continue
            if (pp, bb) not in seen:
                seen.add((pp, bb))
                queue.append(((pp, bb), distance+1))
    return -1


def orbit(rows):
    n = len(rows)
    result = set()
    for reflection in range(2):
        image = [row[::-1] for row in rows] if reflection else rows
        for _ in range(4):
            result.add("".join(image))
            image = ["".join(image[n-1-x][y] for x in range(n)) for y in range(n)]
    return result


def check_result(prefix):
    data = json.loads(prefix.with_suffix(".json").read_text())
    expected = data.get("optimal", data.get("observed_optimal"))
    assert expected is not None
    maps, layouts = {}, {}
    rows = []
    lines = prefix.with_name(prefix.name+"_optimal.xsb").read_text().splitlines()
    for line in lines+[""]:
        if line.startswith(";"):
            continue
        if line:
            rows.append(line)
            continue
        if not rows:
            continue
        assert solve(rows) == data["best"]
        images = orbit(rows)
        key = min(images)
        assert key not in maps
        f = sum(c != "#" for row in rows for c in row)
        maps[key] = (f, len(images))
        images = orbit(["".join("#" if c == "#" else "-" for c in row) for row in rows])
        layouts[min(images)] = (f, len(images))
        rows = []
    counts = defaultdict(lambda: [0, 0, 0, 0])
    for f, size in maps.values():
        counts[f][0] += size
        counts[f][1] += 1
    for f, size in layouts.values():
        counts[f][2] += size
        counts[f][3] += 1
    keys = ("maps", "essential_maps", "layouts", "essential_layouts")
    actual = {key: sum(value[i] for value in counts.values()) for i, key in enumerate(keys)}
    actual.update(score=data["best"], by_F=[dict(F=f, **dict(zip(keys, counts[f]))) for f in sorted(counts)])
    assert actual == expected, (actual, expected)
    assert solve(prefix.with_name(prefix.name+"_best.xsb").read_text().splitlines()) == data["best"]
    return data


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bin", type=Path, default=Path(__file__).parent/"bin")
    parser.add_argument("--full-n6", action="store_true")
    args = parser.parse_args()
    binary = args.bin.resolve()
    suffix = ".exe" if os.name == "nt" else ""

    with tempfile.TemporaryDirectory(prefix="sokoban_search_") as folder:
        work = Path(folder)

        def run(program, *arguments, success=True):
            result = subprocess.run([str(binary/(program+suffix)), *map(str, arguments)],
                                    cwd=work, capture_output=True, text=True, timeout=3600)
            assert (result.returncode == 0) == success, (program, result.stdout, result.stderr)
            if success and "--quiet" in arguments:
                assert result.stdout == "" and result.stderr == ""
            return result

        for program in ("exact", "heuristic", "polish"):
            assert "Usage:" in run(program, "--help").stdout
        expected = {3: (10, 8, 1, [8]), 4: (25, 16, 2, [13, 14]),
                    5: (41, 768, 96, [16, 17, 18, 19, 20])}
        if args.full_n6:
            expected[6] = (78, 8, 1, [28])
        for n, (score, maps, essential, floors) in expected.items():
            prefix = work/f"exact{n}"
            threads = min(24, os.cpu_count() or 1) if n == 6 else 4
            run("exact", n, threads, 0, 1 << (n*n), prefix, -1 if n == 3 else score, "--count", "--quiet")
            data = check_result(prefix)
            assert data["exhaustive"] and data["counts_complete"]
            assert data["best"] == score and data["masks_processed"] == 1 << (n*n)
            assert data["optimal"]["maps"] == maps and data["optimal"]["essential_maps"] == essential
            assert [item["F"] for item in data["optimal"]["by_F"]] == floors
        prefix = work/"overlap5"
        run("exact", 5, 4, 0, 1 << 25, prefix, 41, "--count", "--overlap", "--quiet")
        assert check_result(prefix)["optimal"]["maps"] == 832
        run("exact", 3, 2, 0, 256, work/"partial", -1, "--quiet")
        assert not json.loads((work/"partial.json").read_text())["exhaustive"]
        run("exact", "3x", 1, 0, 512, work/"invalid", -1, success=False)
        run("exact", 3, 1, -1, 512, work/"invalid", -1, success=False)
        run("exact", 3, 1, 0, 512, work/"invalid", -1, "random", success=False)

        seed = work/"exact3_best.xsb"
        for n in (3, 9, 10):
            prefix = work/f"heuristic{n}"
            run("heuristic", n, 1, 2, 20260910+n, seed, prefix, "--quiet")
            data = check_result(prefix)
            assert data["best"] >= 10 and not data["counts_complete"] and not data["exhaustive"]
        run("polish", 3, 2, 2, seed, work/"polish3", "--quiet")
        assert check_result(work/"polish3")["best"] == 10
        invalid = work/"invalid.xsb"
        for content in ("@$..\n----\n----\n", "@@.\n-$-\n---\n", "@$x\n---\n...\n", "@$\n.\n"):
            invalid.write_text(content, encoding="ascii")
            run("heuristic", 3, 1, 1, 1, invalid, work/"bad", success=False)
    print("Passed exact counts, D4/F statistics, independent BFS, heuristic sizes 3/9/10, polish and CLI checks.")


if __name__ == "__main__":
    main()
