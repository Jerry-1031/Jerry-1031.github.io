#pragma once
#include "board.hpp"
#include <algorithm>
#include <string>
#include <vector>

// Keep Board coordinates compatible with the construction tools, but run BFS
// on dense floor indices. A topology is prepared once for all its goals.
struct ScopedSolver {
    std::array<unsigned char, N> prepared{};
    bool ready = false;
    int f = 0;
    std::array<int, N> index{}, cell{};
    std::array<std::array<int, 4>, N> nb{};
    std::vector<int> dist, queue;
    void prepare(const Board &a) {
        if (ready && prepared == a.floor)
            return;
        prepared = a.floor;
        ready = true;
        f = 0;
        index.fill(-1);
        for (int p = 0; p < N; ++p)
            if (a.floor[p]) {
                index[p] = f;
                cell[f++] = p;
            }
        for (int p = 0; p < f; ++p)
            for (int d = 0; d < 4; ++d) {
                int q = cell[p] + delta[d];
                nb[p][d] = q >= 0 && q < N ? index[q] : -1;
            }
        dist.resize(f * f);
        queue.resize(f * f);
    }
    int reverse(Board &a) {
        prepare(a);
        if (a.g < 0 || a.g >= N || index[a.g] < 0)
            return a.score = -1;
        int g = index[a.g], tail = 0;
        std::fill(dist.begin(), dist.end(), -1);
        for (int d = 0; d < 4; ++d) {
            int b = nb[g][d], p = b < 0 ? -1 : nb[b][d];
            if (p < 0)
                continue;
            int s = b * f + p;
            dist[s] = 1;
            queue[tail++] = s;
        }
        for (int head = 0; head < tail; ++head) {
            int s = queue[head], b = s / f, p = s % f, nd = dist[s] + 1;
            for (int d = 0; d < 4; ++d) {
                int pp = nb[p][d];
                if (pp < 0 || pp == b)
                    continue;
                int t = b * f + pp;
                if (dist[t] < 0) {
                    dist[t] = nd;
                    queue[tail++] = t;
                }
                if (nb[p][d ^ 1] == b && p != g) {
                    t = p * f + pp;
                    if (dist[t] < 0) {
                        dist[t] = nd;
                        queue[tail++] = t;
                    }
                }
            }
        }
        int last = tail - 1;
        while (last >= 0 && queue[last] % f == g)
            --last;
        if (last < 0)
            return a.score = -1;
        int s = queue[last];
        a.p = cell[s % f];
        a.b = cell[s / f];
        return a.score = dist[s];
    }
    int forward(Board &a, bool retarget = false) {
        prepare(a);
        if (a.b < 0 || a.b >= N || a.p < 0 || a.p >= N || index[a.b] < 0 || index[a.p] < 0 || a.b == a.p)
            return a.score = -1;
        std::fill(dist.begin(), dist.end(), -1);
        std::array<int, N> bd;
        bd.fill(-1);
        int tail = 0, start = index[a.b] * f + index[a.p], best = 0;
        dist[start] = 0;
        queue[tail++] = start;
        for (int head = 0; head < tail; ++head) {
            int s = queue[head], b = s / f, p = s % f, nd = dist[s] + 1;
            if (bd[b] < 0) {
                bd[b] = nd - 1;
                if (!retarget && cell[b] == a.g)
                    return a.score = nd - 1;
                if (retarget && cell[b] != a.p && cell[b] != a.b && bd[b] > best) {
                    best = bd[b];
                    a.g = cell[b];
                }
            }
            for (int d = 0; d < 4; ++d) {
                int pp = nb[p][d];
                if (pp < 0)
                    continue;
                int bb = pp == b ? nb[b][d] : b;
                if (bb < 0)
                    continue;
                int t = bb * f + pp;
                if (dist[t] < 0) {
                    dist[t] = nd;
                    queue[tail++] = t;
                }
            }
        }
        return a.score = retarget ? best : -1;
    }
    int optimize(Board &a, bool all) {
        prepare(a);
        Board best = a;
        best.score = -1;
        if (all) {
            for (int gi = 0; gi < f; ++gi) {
                Board t = a;
                t.g = cell[gi];
                reverse(t);
                if (t.score > best.score)
                    best = t;
            }
        } else {
            Board t = a;
            reverse(t);
            if (t.score > best.score)
                best = t;
            for (int i = 0; i < 3 && t.score > 0; ++i) {
                int previous = t.score;
                forward(t, true);
                if (t.score > best.score)
                    best = t;
                reverse(t);
                if (t.score > best.score)
                    best = t;
                if (t.score <= previous)
                    break;
            }
            t = a;
            forward(t, true);
            if (t.score > best.score)
                best = t;
        }
        a = best;
        return a.score;
    }
    std::vector<std::string> optimal_maps(const Board &a, int side) {
        prepare(a);
        std::vector<std::string> result;
        for (int gi = 0; gi < f; ++gi) {
            Board t = a;
            t.g = cell[gi];
            reverse(t);
            if (t.score != a.score)
                continue;
            for (int b = 0; b < f; ++b)
                for (int p = 0; p < f; ++p)
                    if (p != gi && b != gi && p != b && dist[b * f + p] == a.score) {
                        std::string s(side * side, '#');
                        for (int y = 1; y <= side; ++y)
                            for (int x = 1; x <= side; ++x)
                                if (a.floor[y * W + x])
                                    s[(y - 1) * side + x - 1] = '-';
                        auto at = [&](int i) { return (cell[i] / W - 1) * side + cell[i] % W - 1; };
                        s[at(p)] = '@';
                        s[at(b)] = '$';
                        s[at(gi)] = '.';
                        result.push_back(s);
                    }
        }
        return result;
    }
};
