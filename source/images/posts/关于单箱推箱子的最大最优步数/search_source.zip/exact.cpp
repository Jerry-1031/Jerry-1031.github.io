#include "cli.hpp"
#include "exact_solver.hpp"

int main(int argc, char **argv) try {
    if (argc < 7 || std::string(argv[1]) == "--help") {
        std::cout << "Usage: exact N THREADS MASK_BEGIN MASK_END PREFIX LOWER_BOUND [--count] [--overlap] "
                     "[--quiet]\n"
                  << "N: 3..7. Interval: [MASK_BEGIN, MASK_END). LOWER_BOUND: verified bound, or -1.\n";
        return argc == 2 && std::string(argv[1]) == "--help" ? 0 : 2;
    }
    int n = number<int>(argv[1], "N"), threads = number<int>(argv[2], "THREADS"),
        lower = number<int>(argv[6], "LOWER_BOUND");
    if (n < 3 || n > 7 || threads < 1 || threads > 256)
        throw std::runtime_error("Requires 3 <= N <= 7 and 1 <= THREADS <= 256");
    Layout l(n);
    U begin = number<U>(argv[3], "MASK_BEGIN"), end = number<U>(argv[4], "MASK_END");
    if (begin >= end || end > l.full + 1)
        throw std::runtime_error("Requires 0 <= MASK_BEGIN < MASK_END <= 2^(N*N)");
    if (lower < -1 || lower > (l.cells - 1) * (l.cells - 1))
        throw std::runtime_error("LOWER_BOUND is outside the valid state-count bound");
    bool distinct = true, count_optima = false, quiet = false;
    for (int i = 7; i < argc; ++i) {
        std::string option = argv[i];
        if (option == "--overlap")
            distinct = false;
        else if (option == "--count")
            count_optima = true;
        else if (option == "--quiet")
            quiet = true;
        else
            throw std::runtime_error("Unknown option: " + option);
    }
    Shared shared(l, lower, argv[5], quiet);
    prepare_output(argv[5]);
    U total = end - begin;
    constexpr U chunk = 4096;
    std::vector<Counters> counters(threads);
    std::vector<std::vector<Record>> records(threads);
    std::vector<std::thread> workers;
    shared.alive = threads;
    auto start = std::chrono::steady_clock::now();
    for (int worker = 0; worker < threads; ++worker)
        workers.emplace_back([&, worker] {
            Solver solver(l, shared, true, distinct, count_optima);
            for (;;) {
                U at = shared.next.fetch_add(chunk);
                if (at >= total)
                    break;
                U stop = std::min(total, at + chunk);
                U low = begin + at, high = begin + stop - 1;
                if ((low % chunk) == 0 && stop - at == chunk && !l.possible_block(low, high)) {
                    solver.stats.masks += stop - at;
                    solver.stats.block_skipped += stop - at;
                } else
                    for (U i = at; i < stop; ++i) {
                        solver.evaluate(begin + i);
                    }
                shared.completed.fetch_add(stop - at);
            }
            counters[worker] = solver.stats;
            records[worker] = std::move(solver.records);
            --shared.alive;
        });
    int last_report = 0;
    while (shared.alive.load()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
        if (!quiet && elapsed >= last_report + 10) {
            last_report = int(elapsed);
            std::lock_guard<std::mutex> lock(shared.mutex);
            std::cout << "progress " << shared.completed.load() << '/' << total << " best "
                      << shared.best.load() << " seconds " << elapsed << std::endl;
        }
    }
    for (auto &worker : workers)
        worker.join();
    double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
    Counters sum;
    for (auto c : counters) {
        sum.masks += c.masks;
        sum.canonical += c.canonical;
        sum.connected += c.connected;
        sum.goals += c.goals;
        sum.bfs += c.bfs;
        sum.states += c.states;
        sum.block_skipped += c.block_skipped;
    }
    OptimalStats opt(n);
    if (count_optima)
        for (const auto &batch : records)
            for (const auto &r : batch)
                if (r.score == shared.best.load()) {
                    // Every solvable map has a unique active floor component. Other floor cells
                    // can be any subset outside its closed neighborhood, without changing OPT.
                    U spare = l.full & ~(r.mask | l.expand(r.mask));
                    U extra = spare;
                    for (;;) {
                        std::string map(l.cells, '#');
                        U mask = r.mask | extra;
                        for (int p = 0; p < l.cells; ++p)
                            if (mask >> p & 1)
                                map[p] = '-';
                        map[r.p] = r.p == r.g ? '+' : '@';
                        map[r.b] = '$';
                        if (r.p != r.g)
                            map[r.g] = '.';
                        opt.add(r.score, map);
                        if (!extra)
                            break;
                        extra = (extra - 1) & spare;
                    }
                    if (shared.witness.score < 0) {
                        shared.witness = r;
                        shared.save(r);
                    }
                }
    if (count_optima)
        opt.save(std::string(argv[5]) + "_optimal.xsb");
    std::ofstream out(std::string(argv[5]) + ".json");
    out << "{\"n\":" << n << ",\"threads\":" << threads << ",\"begin\":" << begin << ",\"end\":" << end
        << ",\"masks_processed\":" << sum.masks << ",\"canonical\":" << sum.canonical
        << ",\"connected\":" << sum.connected << ",\"goals\":" << sum.goals << ",\"bfs\":" << sum.bfs
        << ",\"states\":" << sum.states << ",\"initial_lower_bound\":" << lower
        << ",\"best\":" << shared.best.load() << ",\"distinct\":" << (distinct ? "true" : "false")
        << ",\"complete_interval\":true"
        << ",\"completed_selection\":true,\"elapsed_seconds\":" << elapsed
        << ",\"block_skipped\":" << sum.block_skipped
        << ",\"exhaustive\":" << (begin == 0 && end == l.full + 1 ? "true" : "false")
        << ",\"counts_complete\":"
        << (count_optima && opt.best == shared.best.load() && begin == 0 && end == l.full + 1 ? "true"
                                                                                              : "false");
    if (count_optima) {
        out << ",\"optimal\":";
        opt.write(out);
    }
    out << "}\n";
    if (!quiet)
        std::cout << "finished masks " << sum.masks << " best " << shared.best.load() << " seconds "
                  << elapsed << std::endl;
    return 0;
} catch (const std::exception &error) {
    std::cerr << "error: " << error.what() << '\n';
    return 1;
}
