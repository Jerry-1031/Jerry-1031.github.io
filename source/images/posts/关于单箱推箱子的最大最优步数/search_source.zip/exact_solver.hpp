#pragma once
#include "optimal_stats.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <mutex>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

using U = uint64_t;
inline int bitcount(U a) { return __builtin_popcountll(a); }
inline int first(U a) { return __builtin_ctzll(a); }

struct Layout {
    int n, cells;
    U full, left = 0, right = 0;
    int nb[64][4];
    U transforms[8][8][256]{};
    explicit Layout(int side) : n(side), cells(n * n), full(cells == 64 ? ~U(0) : (U(1) << cells) - 1) {
        for (int y = 0; y < n; ++y) {
            left |= U(1) << (y * n);
            right |= U(1) << (y * n + n - 1);
        }
        const int dy[] = {-1, 1, 0, 0}, dx[] = {0, 0, -1, 1};
        for (int p = 0; p < cells; ++p)
            for (int d = 0; d < 4; ++d) {
                int y = p / n + dy[d], x = p % n + dx[d];
                nb[p][d] = y >= 0 && y < n && x >= 0 && x < n ? y * n + x : -1;
            }
        for (int t = 0; t < 8; ++t)
            for (int chunk = 0; chunk < 8; ++chunk)
                for (int bits = 0; bits < 256; ++bits)
                    for (int bit = 0; bit < 8; ++bit) {
                        int p = chunk * 8 + bit;
                        if (p >= cells || !(bits >> bit & 1))
                            continue;
                        int y = p / n, x = p % n;
                        if (t >= 4)
                            x = n - 1 - x;
                        for (int k = 0; k < t % 4; ++k) {
                            int yy = x;
                            x = n - 1 - y;
                            y = yy;
                        }
                        transforms[t][chunk][bits] |= U(1) << (y * n + x);
                    }
    }
    U expand(U a) const { return ((a << n) | (a >> n) | ((a & ~left) >> 1) | ((a & ~right) << 1)) & full; }
    bool connected(U mask) const {
        if (!mask)
            return false;
        U reached = mask & -mask;
        for (;;) {
            U next = reached | (expand(reached) & mask);
            if (next == reached)
                return reached == mask;
            reached = next;
        }
    }
    bool canonical(U mask) const {
        for (int t = 1; t < 8; ++t) {
            U other = 0;
            for (int c = 0; c < (cells + 7) / 8; ++c)
                other |= transforms[t][c][(mask >> (8 * c)) & 255];
            if (other < mask)
                return false;
        }
        return true;
    }
    U transform(U mask, int t) const {
        U out = 0;
        for (int c = 0; c < (cells + 7) / 8; ++c)
            out |= transforms[t][c][(mask >> (8 * c)) & 255];
        return out;
    }
    bool possible_block(U low, U high) const {
        for (int t = 1; t < 8; ++t)
            if (transform(high, t) < low)
                return false;
        return true;
    }
};

struct Record {
    int score = -1, p = -1, b = -1, g = -1;
    U mask = 0;
};
struct Counters {
    U masks = 0, canonical = 0, connected = 0, goals = 0, bfs = 0, states = 0, block_skipped = 0;
};
struct Shared {
    const Layout &l;
    std::atomic<int> best;
    std::atomic<U> next{0}, completed{0};
    std::atomic<int> alive{0};
    std::mutex mutex;
    Record witness;
    std::string prefix;
    bool quiet;
    Shared(const Layout &layout, int lower, const std::string &path, bool silent = false)
        : l(layout), best(lower), prefix(path), quiet(silent) {}
    void save(const Record &r) {
        std::ofstream out(prefix + "_best.xsb");
        for (int i = 0; i < l.cells; ++i) {
            out << (i == r.p && i == r.g ? '+'
                    : i == r.p           ? '@'
                    : i == r.b           ? '$'
                    : i == r.g           ? '.'
                    : (r.mask >> i & 1)  ? '-'
                                         : '#');
            if (i % l.n == l.n - 1)
                out << '\n';
        }
    }
    void update(const Record &r) {
        if (r.score <= best.load(std::memory_order_relaxed))
            return;
        std::lock_guard<std::mutex> lock(mutex);
        if (r.score <= best.load())
            return;
        witness = r;
        best.store(r.score);
        save(r);
        if (!quiet)
            std::cout << "best " << r.score << std::endl;
    }
};

struct Solver {
    const Layout &l;
    Shared &shared;
    bool pruning, distinct, count_optima;
    Counters stats;
    int nb[64][4];
    U pulls[64]{};
    int record_best = -1;
    std::vector<Record> records;
    uint16_t queue[4096];
    int16_t distance[4096];
    uint16_t next_state[4096][8];
    uint8_t degree[4096];
    Solver(const Layout &a, Shared &s, bool prune, bool dis, bool counts = false)
        : l(a), shared(s), pruning(prune), distinct(dis), count_optima(counts) {}
    void evaluate(U mask) {
        ++stats.masks;
        int f = bitcount(mask);
        int threshold = shared.best.load(std::memory_order_relaxed) - (count_optima ? 1 : 0);
        if (f < 3 || (pruning && (f - 1) * (f - 1) <= threshold))
            return;
        if (!l.canonical(mask))
            return;
        ++stats.canonical;
        if (!l.connected(mask))
            return;
        ++stats.connected;
        int stabilizer[8], symmetries = 0;
        for (int t = 1; t < 8; ++t)
            if (l.transform(mask, t) == mask)
                stabilizer[symmetries++] = t;
        int floor[64], count = 0;
        for (U rest = mask; rest; rest &= rest - 1)
            floor[count++] = first(rest);
        for (int i = 0; i < count; ++i) {
            int p = floor[i];
            pulls[p] = 0;
            for (int d = 0; d < 4; ++d) {
                int q = l.nb[p][d];
                nb[p][d] = q >= 0 && (mask >> q & 1) ? q : -1;
                if (q >= 0 && (mask >> q & 1)) {
                    int support = l.nb[q][d];
                    if (support >= 0 && (mask >> support & 1))
                        pulls[p] |= U(1) << q;
                }
            }
        }
        U prepared = 0;
        for (int gi = 0; gi < count; ++gi) {
            int g = floor[gi];
            if (!pulls[g])
                continue;
            bool goal_representative = true;
            for (int k = 0; k < symmetries; ++k)
                if (l.transform(U(1) << g, stabilizer[k]) < (U(1) << g)) {
                    goal_representative = false;
                    break;
                }
            if (!goal_representative)
                continue;
            ++stats.goals;
            U boxset = U(1) << g, frontier = boxset;
            while (frontier) {
                int b = first(frontier);
                frontier &= frontier - 1;
                U fresh = pulls[b] & ~boxset;
                boxset |= fresh;
                frontier |= fresh;
            }
            if (pruning && (bitcount(boxset) - 1) * (f - 1) <= threshold)
                continue;
            U needed = boxset & ~(U(1) << g) & ~prepared;
            if (needed) {
                // Goal-independent reversed transitions, encoded in 12-bit (box,player) states.
                for (U rest = needed; rest; rest &= rest - 1)
                    for (int pi = 0; pi < count; ++pi) {
                        int b = first(rest), p = floor[pi], s = b * 64 + p;
                        degree[s] = 0;
                        if (b == p)
                            continue;
                        for (int d = 0; d < 4; ++d) {
                            int pp = nb[p][d];
                            if (pp < 0 || pp == b)
                                continue;
                            next_state[s][degree[s]++] = uint16_t(b * 64 + pp);
                            if (nb[p][d ^ 1] == b)
                                next_state[s][degree[s]++] = uint16_t(p * 64 + pp);
                        }
                    }
                prepared |= needed;
            }
            ++stats.bfs;
            std::fill(distance, distance + 4096, int16_t(-1));
            int tail = 0;
            // Seed only the predecessors of the final push, at distance one.
            for (int d = 0; d < 4; ++d) {
                int b = nb[g][d];
                if (b < 0)
                    continue;
                int p = nb[b][d];
                if (p < 0)
                    continue;
                int s = b * 64 + p;
                distance[s] = 1;
                queue[tail++] = uint16_t(s);
            }
            int local = shared.best.load(std::memory_order_relaxed), winning = -1;
            for (int head = 0; head < tail; ++head) {
                int s = queue[head], value = distance[s];
                if (value > local && (!distinct || (s & 63) != g)) {
                    local = value;
                    winning = s;
                }
                for (int i = 0; i < degree[s]; ++i) {
                    int t = next_state[s][i];
                    if ((t >> 6) == g || distance[t] >= 0)
                        continue;
                    distance[t] = int16_t(value + 1);
                    queue[tail++] = uint16_t(t);
                }
            }
            stats.states += tail;
            if (winning >= 0)
                shared.update({local, winning & 63, winning >> 6, g, mask});
            if (count_optima) {
                int target = shared.best.load(std::memory_order_relaxed);
                if (target > record_best) {
                    records.clear();
                    record_best = target;
                }
                for (int i = tail - 1; i >= 0 && distance[queue[i]] >= target; --i) {
                    int s = queue[i];
                    if (distance[s] == target && (!distinct || (s & 63) != g))
                        records.push_back({target, s & 63, s >> 6, g, mask});
                }
            }
        }
    }
};
