#pragma once
#include <array>
#include <cstdint>

constexpr int W = 22, N = W * W;
constexpr int delta[] = {-W, W, -1, 1};
struct Board {
    std::array<unsigned char, N> floor{};
    int p = 0, b = 0, g = 0, score = -1;
};
inline Board transform(const Board &a, int y1, int x1, int y2, int x2, int kind, int amount) {
    Board t = a;
    int h = y2 - y1 + 1, w = x2 - x1 + 1;
    for (int y = y1; y <= y2; ++y)
        for (int x = x1; x <= x2; ++x) {
            int yy = y, xx = x;
            if (kind == 0)
                xx = x1 + (x - x1 + w + amount % w) % w;
            if (kind == 1)
                yy = y1 + (y - y1 + h + amount % h) % h;
            if (kind == 2)
                xx = x1 + x2 - x;
            if (kind == 3)
                yy = y1 + y2 - y;
            if (kind == 4) {
                xx = x1 + x2 - x;
                yy = y1 + y2 - y;
            }
            int p = y * W + x, q = yy * W + xx;
            t.floor[q] = a.floor[p];
            if (a.p == p)
                t.p = q;
            if (a.b == p)
                t.b = q;
            if (a.g == p)
                t.g = q;
        }
    return t;
}

inline uint64_t hash_board(const Board &a) {
    uint64_t h = 1469598103934665603ULL;
    for (int i = 0; i < N; ++i)
        h = (h ^ a.floor[i]) * 1099511628211ULL;
    return h;
}
