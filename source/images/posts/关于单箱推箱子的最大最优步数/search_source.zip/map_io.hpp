#pragma once
#include "board.hpp"
#include <fstream>
#include <stdexcept>
#include <string>

inline Board load_seed(const std::string &path, int side) {
    Board board;
    if (path == "-") {
        for (int y = 1; y <= side; ++y)
            for (int x = 1; x <= side; ++x)
                board.floor[y * W + x] = 1;
        board.p = W + 1;
        board.b = 2 * W + 2;
        board.g = side * W + side;
        return board;
    }
    std::ifstream input(path);
    if (!input)
        throw std::runtime_error("Cannot read seed map: " + path);
    std::string row;
    int height = 0, width = -1, players = 0, boxes = 0, goals = 0;
    while (std::getline(input, row)) {
        if (!row.empty() && row.back() == '\r')
            row.pop_back();
        if (width < 0)
            width = int(row.size());
        if (++height > side || width < 1 || width > side || int(row.size()) != width)
            throw std::runtime_error("Seed must be rectangular and fit inside the requested size: " + path);
        for (int x = 1; x <= width; ++x) {
            char ch = row[x - 1];
            int p = height * W + x;
            if (std::string("#- @$.").find(ch) == std::string::npos)
                throw std::runtime_error("Seed accepts only #, -, space, @, $, .: " + path);
            board.floor[p] = ch != '#';
            if (ch == '@') {
                board.p = p;
                ++players;
            }
            if (ch == '$') {
                board.b = p;
                ++boxes;
            }
            if (ch == '.') {
                board.g = p;
                ++goals;
            }
        }
    }
    if (players != 1 || boxes != 1 || goals != 1)
        throw std::runtime_error("Seed must contain exactly one @, one $, and one .: " + path);
    return board;
}
