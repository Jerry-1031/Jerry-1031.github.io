#pragma once
#include <charconv>
#include <filesystem>
#include <stdexcept>
#include <string>
#include <system_error>

template <class T> T number(const char *text, const char *name) {
    T value{};
    std::string input(text);
    auto result = std::from_chars(input.data(), input.data() + input.size(), value);
    if (result.ec != std::errc{} || result.ptr != input.data() + input.size())
        throw std::runtime_error(std::string("Invalid ") + name + ": " + input);
    return value;
}

inline void prepare_output(const std::string &prefix) {
    if (prefix.empty())
        throw std::runtime_error("Output prefix must not be empty");
    auto parent = std::filesystem::path(prefix).parent_path();
    if (!parent.empty())
        std::filesystem::create_directories(parent);
}
