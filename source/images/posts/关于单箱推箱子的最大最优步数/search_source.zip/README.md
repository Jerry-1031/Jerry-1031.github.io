# 单箱推箱子搜索

此目录包含可独立构建的 C++17 搜索代码，不依赖上级目录的实验程序、地图或 Python 包。

| 入口 | 用途 | 边长 |
|---|---|---|
| `exact.cpp` | 多线程精确区间枚举、最优地图完整计数 | 3～7 |
| `heuristic.cpp` | 多线程启发式搜索、已发现地图统计 | 3～20 |
| `polish.cpp` | 多线程窗口全重写与标记位置优化 | 3～8 |

`exact_solver.hpp` 是位图枚举内核，`scoped_solver.hpp` 是压缩状态 BFS，`board.hpp` 定义墙图与变异操作，`optimal_stats.hpp` 负责对称去重和 F 分布，`map_io.hpp` 与 `cli.hpp` 负责输入。只需要前两个搜索工具时，可以不编译 `polish.cpp`。

## 构建

Windows PowerShell，需要 PATH 中有支持 C++17 的 MinGW GCC：

```powershell
cd search
.\build.ps1
```

输出到 `bin/`。默认使用本机 CPU 指令；跨机器分发二进制时用 `./build.ps1 -Portable`。编译器路径可通过 `-Compiler` 指定。

也可直接用 GCC 或 Clang 编译，例如在 Linux 上：

```text
g++ -O3 -std=c++17 -pthread exact.cpp -o exact
g++ -O3 -std=c++17 -pthread heuristic.cpp -o heuristic
g++ -O3 -std=c++17 -pthread polish.cpp -o polish
```

位操作内核使用 GCC／Clang 内建函数，不支持直接用 MSVC 编译。程序使用 CPU 多线程，没有 GPU 内核。

## 精确枚举

```powershell
.\bin\exact.exe 5 24 0 33554432 results/n5 41 --count
.\bin\exact.exe 6 24 0 68719476736 results/n6 78 --count
```

参数为 `N THREADS MASK_BEGIN MASK_END PREFIX LOWER_BOUND`。

- 区间是 `[MASK_BEGIN, MASK_END)`，完整枚举的区间为 `[0, 2^(N*N))`。
- `LOWER_BOUND` 必须来自已验证构造；程序不会验证用户输入的下界。未知下界时传 `-1`，由程序自行寻找。
- `--count` 统计所有达到本轮最好分数的地图，保存每个本质不同类的代表。
- `--overlap` 允许人初始站在目标上，以 `+` 表示。默认人、箱、目标互异。
- `--quiet` 关闭进度和完成信息，不影响结果文件与错误提示。
- 精确枚举支持 1～256 个线程。可以分区间运行，但单个分片并非全空间证明，也没有自动断点续跑。

这是一套完整区间枚举入口，不提供随机抽样、步长抽样或关闭剪枝的调试选项。计数模式保留剪枝边界上的并列最优。

## 启发式搜索

```powershell
.\bin\heuristic.exe 9 300 24 20260910 - results/n9
.\bin\heuristic.exe 10 300 24 20260911 results/n9_best.xsb results/n10
```

参数为 `N SECONDS THREADS RNG_SEED MAP_OR_DASH PREFIX`，可追加 `--quiet`。支持 1～32 个线程。

`-` 从全空正方形出发。种子文件为单张矩形 XSB 地图，只接受 `#`（墙）、`-` 或空格（空地）、`@`（人）、`$`（箱）、`.`（目标），三枚标记各一枚。较小地图在右侧和下侧填墙，之后搜索可以修改整个目标尺寸。过大、不规则或标记错误的输入会被拒绝。

每个线程使用退火、局部变异、区域变换和共享种群，候选通过完整状态 BFS 评分。边长不超过 8 时启用候选缓存；缓存同时核对墙图和三枚输入标记位置。时间预算控制搜索循环，不包含初始种子优化和最终文件输出。固定随机种子也不保证多线程按时间停止时得到相同轨迹。

## 窗口优化

```powershell
.\bin\polish.exe 7 24 4 seed7.xsb results/n7_polish
```

参数为 `N THREADS WINDOW SEED_MAP PREFIX`，可追加 `--quiet`。`WINDOW` 为 1～4，且不大于边长；线程数为 1～256。

程序枚举每个窗口内的全部墙／地组合，并精确优化三枚标记位置。若找到严格更高分，则围绕新构造再跑一轮；没有提升时停止。它只检查最后一张构造的窗口邻域，不是全局精确枚举，也不保证所有并列最好图的邻域都被检查。

## 输出与计数

三个程序均使用输出前缀 `PREFIX`：

| 文件 | 内容 |
|---|---|
| `PREFIX.json` | 分数、运行统计、枚举覆盖状态和计数 |
| `PREFIX_best.xsb` | 最好构造 |
| `PREFIX_optimal.xsb` | 去重后的最好分数代表图集合 |

精确程序仅在 `--count` 时生成代表图集合；若给了下界、没有开计数且没找到更高值，则不会生成新的最好构造。各轮应使用不同前缀，避免旧输出与新结果混淆。

“地图”包括墙图和人、箱、目标位置。本质不同按正方形的 8 种旋转／镜像去重，不额外合并平移。F 包括全部非墙格，包含额外孤立空地。

| JSON 计数字段 | 含义 |
|---|---|
| `maps` | 保留坐标方向的完整标记地图数量 |
| `essential_maps` | 完整标记地图的对称类数量 |
| `layouts` | 存在最好分数标记配置的墙布局数量 |
| `essential_layouts` | 上述墙布局的对称类数量 |
| `by_F` | 按可通行格数拆分以上四种计数 |

精确程序使用 `optimal`，启发式和窗口程序使用 `observed_optimal`。`counts_complete:true` 只在精确程序覆盖全空间、开启计数且找到报告分数的构造时成立。它以输入下界正确为前提。启发式和窗口程序始终标记 `exhaustive:false`、`counts_complete:false`；它们给出已发现地图的计数和 M(n) 的下界。

精确程序只评估活动空地连通分量，计数时恢复不接触该分量的全部额外空地子集。区间计数包含所发现构造的对称轨道和额外空地扩展，并不限于该数值区间。因此合并分片或多轮结果必须重新去重代表图，不能直接相加。

`masks_processed` 包括被对称性整块跳过的编号，表示已处理的区间覆盖量。精确 JSON 中保留的 BFS、状态和剪枝计数用于核验覆盖与性能；常规终端输出只报告最好分数、进度和完成信息。启发式的 `evaluated` 包含重复候选及 `cache_hits`。

## 验证

需要 Python 3，仅使用标准库：

```powershell
python verify.py
```

验证程序在临时目录运行，检查三至五阶完整计数、五阶重叠规则、F 分布和 D4 去重，独立正向 BFS 验证保存的代表图，并检查九／十阶启发式、窗口优化、输入校验和静默输出。可用 `--bin .` 指向直接编译得到的程序，或用 `--full-n6` 增加六阶完整枚举检查。
